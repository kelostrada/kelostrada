package Odwracanko;

/**
 * @author bartosz.kalinowski
 */
public interface Reversible {
    public void reverse();
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Szpital;

/**
 *
 * @author bartosz.kalinowski
 */
class ChoryNaDyspepsje extends Pacjent {

    public ChoryNaDyspepsje() {
    }
    
    public ChoryNaDyspepsje(String name) {
        super(name);
    }

    @Override
    public String choroba() {
        return "dyspepsja";
    }

    @Override
    public String leczenie() {
        return "węgiel";
    }
    
}

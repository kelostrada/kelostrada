/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Szpital;

/**
 *
 * @author bartosz.kalinowski
 */
class ChoryNaGlowe extends Pacjent {
    
    public ChoryNaGlowe() {
    }
    
    public ChoryNaGlowe(String name) {
        super(name);
    }

    @Override
    public String choroba() {
        return "głowa";
    }

    @Override
    public String leczenie() {
        return "aspiryna";
    }
    
}
